<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    use HasFactory;

    protected $fillable = [
    	'comment',
    	'user_id',
    	'event_id'
    ];

    public function event()
    {
    	return $this->belongsTo(Event::class);
    }

    public function user()
    {
    	return $this->belongsTo(User::class);
    }
}
