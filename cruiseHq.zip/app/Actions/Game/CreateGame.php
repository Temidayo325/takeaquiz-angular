<?php 
declare(strict_types = 1);

namespace App\Actions\Game;

use App\Actions\Event\EventTags;

/**
 * 
 */
class CreateGame extends EventTags
{
	
	function __invoke($gameToBeCreated)
	{
        $image_path = $gameToBeCreated->picture->store('/images/games');
		$game = \App\Models\Game::create([
			'name' => $gameToBeCreated->name, 
	    	'summary' => $gameToBeCreated->summary,
	    	'stepByStep' => $gameToBeCreated->stepByStep,
	    	'minimum_player' => $gameToBeCreated->minimum_player,
	    	'maximum_player' => $gameToBeCreated->maximum_player,
	    	'tags' => json_encode($this->turnStringTagsToArray( $gameToBeCreated->tags)),
	    	'image' => $image_path
		]);
		// $tag = new EventTags();
		// $tag->add($gameToBeCreated->tags, $game);
		// return $game;
	}

	private function turnStringTagsToArray(string $tags):Array
	{
		$tagArray = explode(',', $tags);
		$newCleanedTagArray = [];
		if ( count($tagArray) > 1 ) {
			foreach ($tagArray as $tag) {
				# code...
				array_push($newCleanedTagArray, preg_replace('/[^a-zA-Z0-9-]/', '', strip_tags(trim($tag))));
			}
		}
		return $newCleanedTagArray;
	}
}