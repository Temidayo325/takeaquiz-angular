

<?php $__env->startSection('title', 'Welcome to your homepage'); ?>

<?php $__env->startSection('content'); ?>
	<div class="text-purple-1000 flex justify-between items-center pt-10 mb-3 px-4 md:px-12">
		<h1 class="font-bold text-lg">Profile</h1>
	</div>
	<div class="py-4 px-4 md:px-12 font-body text-purple-1000 pb-20">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-0 space-y-6 grid gap-10">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\cruiseHq\resources\views/dashboard/profile.blade.php ENDPATH**/ ?>