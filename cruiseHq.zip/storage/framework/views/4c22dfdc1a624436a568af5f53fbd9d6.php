<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['games', 'tags']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['games', 'tags']); ?>
<?php foreach (array_filter((['games', 'tags']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div 	class="text-purple-1000 px-4 md:px-12" 
			x-data='{ games: <?php echo json_encode($games, 15, 512) ?>,
					tags: <?php echo json_encode($tags, 15, 512) ?>,
					searchterm: "",
					chosenGame: null,
					init(){
						
					},
					fetchData(cursor)
					{
						this.toast("Fetching more games ...", "blue")
						try {
			                axios.post("/admin/dashboard/games/paginate", {cursor: cursor})
			                .then(response => {
			                	this.toast("Games retrieved successfully", "green")
			                	this.games = response.data
			            	})
			                .catch((error) => {
			                	this.toast("Encountered an error while retrieving games", "red")
			            	})
			            } catch (error) {
			                this.toast("Encountered an error while retrieving games", "red")
			            }
					},
					searchTerm()
					{
						this.toast("Searching for games ... ", "blue")
						axios.post("/admin/dashboard/games/search", {searchTerm: this.searchterm})
						.then( ( response ) => {
							if(!response.error)
							{
								this.games = response.data.games
								this.toast("Games returned", "green")
							}
						})
						.catch((error) => {
							this.toast("Encountered an error while retrieving games", "red")
						})
					},
					searchByTag(tag)
					{
						this.toast("Searching for games with " + tag + " tag ... ", "blue")
						axios.post("/games/search/tag", {tag: tag})
						.then( ( response ) => {
							if(!response.error)
							{
								this.games = response.data.games
								this.toast("Games with " + tag + " tags returned", "green")
							}
						})
						.catch((error) => {
							this.toast("Encountered an error while retrieving games", "red")
						})
					},
					viewGameDetails(game)
					{
						this.chosenGame = game
						$refs.sideBarButton.dispatchEvent(new Event("click"))
					},
					toast(text, background)
					{
						Toastify({
						  text: text, 
						  style: {
						    background: background,
						    color: "white"
						  }
						}).showToast();
					},
	}'>
		<div class="mt-6">
			<h1 class=" text-5xl font-normal font-display text-purple-1000 tracking-wider py-3">Fun Games Brings the gatherings to Life!!</h1>
			<h3 class="text-lg font-body font-bold text-purple-1000 mb-3">Your one-stop destination for game inspiration.</h3>
			<?php if (isset($component)) { $__componentOriginale88367bb5c9f9c1fb422589b8f4866b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale88367bb5c9f9c1fb422589b8f4866b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.games.carousel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('games.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale88367bb5c9f9c1fb422589b8f4866b8)): ?>
<?php $attributes = $__attributesOriginale88367bb5c9f9c1fb422589b8f4866b8; ?>
<?php unset($__attributesOriginale88367bb5c9f9c1fb422589b8f4866b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale88367bb5c9f9c1fb422589b8f4866b8)): ?>
<?php $component = $__componentOriginale88367bb5c9f9c1fb422589b8f4866b8; ?>
<?php unset($__componentOriginale88367bb5c9f9c1fb422589b8f4866b8); ?>
<?php endif; ?>
			
			<div class="mt-8" x-show="games.data.length > 0">
				<h1 class="font-bold text-md mt-4 ">Popular game tags</h1>
				<div class="flex gap-6 justify-start items-center overflow-x-scroll py-6">
					<template x-for="tag in tags">
						<button x-text="tag" class="rounded-full no-wrap px-4 md:px-8 py-2 shadow-lg text-nowrap bg-purple-1000 text-gray-200 font-body" @click="searchByTag(tag)"></button>
					</template>
				</div>
			</div>
			<h1 class="font-bold font-body text-md mt-4 md:hidden" x-show="games.data.length > 0">View available games</h1>
			<div class="mt-2 md:mt-6" x-show="games.data.length > 0">
				<form action="" method="" class="flex justify-start " @submit.prevent="searchTerm()">
					<?php echo csrf_field(); ?>
					<input type="text" class="w-full text-sm px2 py-1 md:py-2 focus:outline-0 focus:border-lightpurple focus:ring-0 md:w-2/6" x-model="searchterm" placeholder="e.g. spin the bottle" @input.debounce.500ms="searchTerm">
					
				</form>
			</div>
		</div>
		<div>
			<template x-if="games.data.length > 0 ">
				<div >
					<div class="w-full pb-10 py-10 grid grid-cols-2 gap-x-3 gap-y-10 md:grid-cols-4 md:gap-10">
						<template x-for="game in games.data">
							<button class="hover:shadow-xl hover:border-2 hover:border-gray-300 hover:transition-border game-card-ui shadow border border-gray-200 w-full bg-white text-gray-950 tracking-widest cursor-pointer" title="Click to view more information" @click="viewGameDetails(game)">
								<img :src="`<?php echo e(asset('images')); ?>/${game.image}`" alt="Image depicting the game" class="w-full h-32">
								<div class="px-2 py-1 text-sm">
									<h2 class="font-bold text-center md:text-lg md:py-1" x-text="game.name">Name of the game</h2>
									<p>
										<span>Min:<span class="font-bold" x-text="game.minimum_player"></span></span>
										<span>Max:<span class="font-bold" x-text="game.maximum_player"></span></span>
									</p>
								</div>
							</button>
						</template>
					</div>
					<div class="flex justify-end gap-10 my-1 pb-20">
						<template x-if="games.prev_cursor != null">
							<button class="px-8 py-2 bg-gray-900 text-gray-400" @click="fetchData(games.prev_cursor)" >Prev</button>
						</template>
						<template x-if="games.next_cursor != null">
							<button class="px-8 py-2 bg-gray-900 text-gray-400" @click="fetchData(games.next_cursor)">Next</button>
						</template>
					</div>
				</div>
			</template>
			<template x-if="games.data.length <= 0">
				<h2 class="text-center font-bold font-body text-xl py-20 ">You have not created any games yet</h2>
			</template>
			<?php if (isset($component)) { $__componentOriginalba41b47a3ad2877078b7c8d63f5f0e85 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba41b47a3ad2877078b7c8d63f5f0e85 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-toggle-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar-toggle-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba41b47a3ad2877078b7c8d63f5f0e85)): ?>
<?php $attributes = $__attributesOriginalba41b47a3ad2877078b7c8d63f5f0e85; ?>
<?php unset($__attributesOriginalba41b47a3ad2877078b7c8d63f5f0e85); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba41b47a3ad2877078b7c8d63f5f0e85)): ?>
<?php $component = $__componentOriginalba41b47a3ad2877078b7c8d63f5f0e85; ?>
<?php unset($__componentOriginalba41b47a3ad2877078b7c8d63f5f0e85); ?>
<?php endif; ?>
			  
			<!-- drawer component -->
		    <div id="drawer-right-example" class="fixed top-0 right-0 z-40 w-64 md:w-96 h-screen p-4 overflow-y-auto transition-transform translate-x-full bg-gray-200 dark:bg-gray-800" tabindex="-1" aria-labelledby="drawer-navigation-label">
		        <button type="button" data-drawer-hide="drawer-right-example" aria-controls="drawer-right-example" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 absolute top-2.5 end-2.5 inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white">
		            <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
		            <span class="sr-only">Close menu</span>
		        </button>
		        <div class="py-4 overflow-y-auto text-black my-10">
					<template x-if="chosenGame != null">
						<div class="game-card-ui shadow border border-gray-200 w-full bg-white text-gray-950 tracking-widest cursor-pointer pb-10" title="Click to view more information" >
							<img :src="`<?php echo e(asset('images')); ?>/${chosenGame.image}`" alt="Image depicting the game" class="w-full h-auto">
							<div class="px-4 py-2">
								<h2 class="font-display leading-9 text-center mb-4 md:text-lg md:py-1" x-text="chosenGame.name">Name of the game</h2>
								<h4 class="font-bold text-md">Game summary</h4>
								<p x-text="chosenGame.summary" class="text-sm leading-8"></p>
								<p class="mt-4">
									<strong>Min players : </strong>
									<span x-text="chosenGame.minimum_player"></span>
								</p>
								<p class="mt-2">
									<strong>Max players : </strong>
									<span x-text="chosenGame.maximum_player"></span>
								</p>
								<?php if(auth()->guard()->check()): ?>
									<div>
										<h4 class="mt-8 font-bold text-md">How to play</h4>
										<ul class="mt-2 px-10 py-2">
											<template x-for="step in chosenGame.stepByStep" class="">
												<li x-text="step" class="list-decimal py-1"></li>
											</template>
										</ul>

										<h4 class="mt-8 font-bold text-md">Required Materials or Setup</h4>
										<ul class="mt-2 px-10 py-2">
											<template x-for="material in chosenGame.materials" class="">
												<li x-text="material" class="list-decimal py-1"></li>
											</template>
										</ul>

										<h4 class="mt-8 font-bold text-md">Estimated Playtime</h4>
										<p x-text="chosenGame.play_time" class="text-sm leading-8"></p>

										<h4 class="mt-8 font-bold text-md">Difficulty Level</h4>
										<p x-text="chosenGame.difficulty_level" class="text-sm leading-8"></p>

										<h4 class="mt-8 font-bold text-md">Player Category</h4>
										<p x-text="chosenGame.category" class="text-sm leading-8"></p>

										<h4 class="mt-8 font-bold text-md">Ideal setting</h4>
										<p x-text="chosenGame.ideal_setting" class="text-sm leading-8"></p>

										<h4 class="mt-8 font-bold text-md">Objective or Win Condition</h4>
										<p x-text="chosenGame.objective" class="text-sm leading-8"></p>

										<h4 class="mt-8 font-bold text-md">Tips for Success</h4>
										<p x-text="chosenGame.tips" class="text-sm leading-8"></p>										
									</div>
								<?php endif; ?>
							</div>
						</div>
					</template>
		        </div>
		    </div>
		</div>
	</div><?php /**PATH C:\wamp\www\cruiseHq\resources\views/components/games/all-games.blade.php ENDPATH**/ ?>