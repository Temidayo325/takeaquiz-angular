

<?php $__env->startSection('title', 'Welcome to Admin dashboard'); ?>

<?php $__env->startSection('content'); ?>
	<div class="text-black px-10" x-data='{ user: <?php echo json_encode($user, 15, 512) ?>,
		init() {
        	sessionStorage.setItem("user", JSON.stringify(this.user))
   		}
	}'>
		<h1>Admin Homepage dashboard</h1>
	</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\cruiseHq\resources\views/dashboard/admin/index.blade.php ENDPATH**/ ?>