<section class="mt-10 w-full bg-white py-5 px-4 grid gap-6" x-data='{event_id: sessionStorage.getItem("event_id"), 
	spinner: false,
	createPromotionalVideoButtonText: "Add promotional video",
	toast(text, background)
	{
		Toastify({
		  text: text, 
		  style: {
		    background: background,
		    color: "white"
		  }
		}).showToast();
	},
	submitForm(){
		$refs.AddPromotionalVideo.setAttribute("disabled", "")
		this.spinner = true
		this.createPromotionalVideoButtonText = "Uploading promotional video ..."
		this.toast("Uploading promotional video ...", "blue")
		
		let formdata = new FormData()
		formdata.append("video", $refs.video.files[0]);
		formdata.append("event_id", this.event_id);
		console.log(this.event_id)
		axios.post("/promoter/dashboard/events/promotional_video", formdata)
		.then( (response) => {
			$refs.AddPromotionalVideo.removeAttribute("disabled")
			this.spinner = true
			this.createPromotionalVideoButtonText = "Add promotional video"
			this.toast("Edit saved Succesfully", "green")
			
		})
		.catch( (error) => {
			this.spinner = false
			this.createPromotionalVideoButtonText = "Add promotional video"
			$refs.AddPromotionalVideo.removeAttribute("disabled")
			this.toast(error.response.data.message, "#DB162F")
			this.errorMessage = error.response.data.message
		})
	},
}'>
	<header>
        <h2 class="text-lg font-medium text-purple-1000 dark:text-gray-100">
            <?php echo e(__('Add Video promotional material and additional image to the event')); ?>

        </h2>

        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            <?php echo e(__(" Add a short promotional video to promote the event")); ?>

        </p>
    </header>
	<form action="" x-ref="form" @submit.prevent="submitForm" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<div>
            <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'video','value' => __('Promotional video')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'video','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Promotional video'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
            <p class="my-1 text-sm text-red-1000">Kindly ensure the file size does not exceed 40MB</p>
            <input type="file" name="video" id="video" required class="w-56 border border-gray-300 shadow-md focus:shadow-lg transition duration-500 focus:border-gray-500 focus:outline-none focus:ring-0 md:w-full" x-ref="video">
            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('video')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('video'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>

        <div class="flex items-center gap-4 mt-6">
            <button type="submit"  x-ref="AddPromotionalVideo" class="w-full py-3 bg-red-1000 border-none text-gray-200 mt-4 hover:bg-red-900 duration-500" x-text="createPromotionalVideoButtonText"></button>
        </div>
	</form>
</section><?php /**PATH C:\wamp\www\cruiseHq\resources\views/components/event/add-premium-media.blade.php ENDPATH**/ ?>