<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
        <link rel="manifest" href="/site.webmanifest">
        
        <title><?php echo $__env->yieldContent('title', config('app.name') ); ?></title>
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans text-gray-900 antialiased">
        <div class="min-h-screen flex flex-col sm:justify-end justify-end md:justify-center md:bg-purple-1000 md:bg-blend-multiply items-center pt-6 sm:pt-0 bg-gray-100 dark:bg-gray-900 bg-login bg-cover">
            

            <div class="w-full sm:max-w-md mt-6 px-6 pt-6 pb-4 bg-white md:border md:border-white dark:bg-gray-800 shadow-md overflow-hidden sm:rounded-lg rounded-tr-2xl rounded-tl-2xl">
                <?php echo e($slot); ?>

            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\wamp\www\cruiseHq\resources\views/layouts/guest.blade.php ENDPATH**/ ?>