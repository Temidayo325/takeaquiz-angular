

<?php $__env->startSection('title', 'Create a new event'); ?>

<?php $__env->startSection('content'); ?>
	<div class="text-purple-1000 px-4 md:px-10 pb-20" x-data='{user: JSON.parse(localStorage.getItem("user"))}'>
		<div class="hidden md:flex py-6 md:py-10 bg-purple-300 items-center justify-between md:px-12 px-4">
			<div class="max-w-lg">
				<h1 class="font-display text-2xl tracking-wider md:text-4xl font-normal">Welcome back <span x-text="user.nickname"></span></h1>
				<p class="text-md leading-7 my-4">Create your events here, make the details as exciting and simple as possble. And don't forget to add appropriate tags as they woud help users search and sort events appropriately.</p>
				<a href="/promoter/dashboard/events" class="px-4 py-3 mt-3 font-bold md:font-normal bg-red-1000 text-gray-200">View all my events</a>
			</div>
			<img src="<?php echo e(asset('/images/create-ticket.svg')); ?>" alt="People chilling" class="w-96 h-52">
		</div>
		<div>
			<h1 class="font-body font-bold text-md md:text-lg pt-5 pb-3 md:mt-10">Create an event</h1>
		</div>
		<?php if (isset($component)) { $__componentOriginal6ad743d4f6a6c57e341e3dc23a7fea05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6ad743d4f6a6c57e341e3dc23a7fea05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.create-event-form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('create-event-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6ad743d4f6a6c57e341e3dc23a7fea05)): ?>
<?php $attributes = $__attributesOriginal6ad743d4f6a6c57e341e3dc23a7fea05; ?>
<?php unset($__attributesOriginal6ad743d4f6a6c57e341e3dc23a7fea05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ad743d4f6a6c57e341e3dc23a7fea05)): ?>
<?php $component = $__componentOriginal6ad743d4f6a6c57e341e3dc23a7fea05; ?>
<?php unset($__componentOriginal6ad743d4f6a6c57e341e3dc23a7fea05); ?>
<?php endif; ?>
	</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\cruiseHq\resources\views/dashboard/promoter/event/create.blade.php ENDPATH**/ ?>