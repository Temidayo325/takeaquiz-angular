<aside>
      <!-- drawer init and toggle -->
      <div class="text-center">
         <button class="text-black bg-white" type="button" data-drawer-target="drawer-right-example" data-drawer-show="drawer-right-example" data-drawer-placement="right" aria-controls="drawer-right-example" id="right-drawer-button" >
         Show right drawer
         </button>
      </div>

      <!-- drawer component -->
      <div id="drawer-right-example" class="fixed top-0 right-0 z-40 h-screen p-4 overflow-y-auto transition-transform translate-x-full bg-white w-6/12 dark:bg-gray-800" tabindex="-1" aria-labelledby="drawer-right-label">
         <button type="button" data-drawer-hide="drawer-right-example" aria-controls="drawer-right-example" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 absolute top-2.5 end-2.5 inline-flex items-center justify-center dark:hover:bg-gray-600 dark:hover:text-white" >
            <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
               <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
            </svg>
            <span class="sr-only">Close menu</span>
         </button>
         <div class="mt-20 ">
            <button onClick="enableFormEditing()" id="editButton" class="px-6 py-2 bg-blue-600 text-white shadow-md mx-auto disabled:bg-gray-200 disabled:text-black shadow-md disabled:shadow-none">Edit</button>
            <img src="" alt="" name="image" class="mx-auto image">
            <input type="file" class="my-2 border border-gray-300 py-2 px-5" name="image" id="imageFile">
            
         </div>
   </aside><?php /**PATH C:\wamp\www\cruiseHq\resources\views/components/off-canvas-side-bar.blade.php ENDPATH**/ ?>