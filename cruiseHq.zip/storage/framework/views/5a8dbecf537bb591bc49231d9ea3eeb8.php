

<?php $__env->startSection('title', 'Checkout games for events'); ?>

<?php $__env->startSection('content'); ?>
	<?php if (isset($component)) { $__componentOriginal7dca3e21391333824ac77e28ed5e35e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7dca3e21391333824ac77e28ed5e35e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.games.all-games','data' => ['games' => $games,'tags' => $tags]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('games.all-games'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['games' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($games),'tags' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tags)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7dca3e21391333824ac77e28ed5e35e7)): ?>
<?php $attributes = $__attributesOriginal7dca3e21391333824ac77e28ed5e35e7; ?>
<?php unset($__attributesOriginal7dca3e21391333824ac77e28ed5e35e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7dca3e21391333824ac77e28ed5e35e7)): ?>
<?php $component = $__componentOriginal7dca3e21391333824ac77e28ed5e35e7; ?>
<?php unset($__componentOriginal7dca3e21391333824ac77e28ed5e35e7); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\cruiseHq\resources\views/dashboard/user/game/index.blade.php ENDPATH**/ ?>