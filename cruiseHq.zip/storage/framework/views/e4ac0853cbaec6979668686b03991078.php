

<?php $__env->startSection('title', 'My dashboard'); ?>

<?php $__env->startSection('content'); ?>
	<?php if (isset($component)) { $__componentOriginaldfddcfd9338941b9fbd0aed6aa2453e0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldfddcfd9338941b9fbd0aed6aa2453e0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.event.calender','data' => ['events' => $events,'eventsToday' => $events_today,'premiumEvents' => $premium_events]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('event.calender'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['events' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($events),'events_today' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($events_today),'premium_events' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($premium_events)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldfddcfd9338941b9fbd0aed6aa2453e0)): ?>
<?php $attributes = $__attributesOriginaldfddcfd9338941b9fbd0aed6aa2453e0; ?>
<?php unset($__attributesOriginaldfddcfd9338941b9fbd0aed6aa2453e0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldfddcfd9338941b9fbd0aed6aa2453e0)): ?>
<?php $component = $__componentOriginaldfddcfd9338941b9fbd0aed6aa2453e0; ?>
<?php unset($__componentOriginaldfddcfd9338941b9fbd0aed6aa2453e0); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\cruiseHq\resources\views/dashboard/user/event/index.blade.php ENDPATH**/ ?>