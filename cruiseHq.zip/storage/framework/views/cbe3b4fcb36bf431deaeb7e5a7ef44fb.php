

<?php $__env->startSection('title', 'Checkout your ticket'); ?>

<?php $__env->startSection('content'); ?>
	<div class="text-black px-0" x-data='{ user: <?php echo json_encode($user, 15, 512) ?>,
		desiredTicket: <?php echo json_encode($ticket, 15, 512) ?>,
		chosenEvent: null,
		init() {
        	sessionStorage.setItem("ticket", JSON.stringify(this.desiredTicket))
        	console.log(this.ticket)
        	this.chosenEvent = this.desiredTicket.event
   		}
	}'>
		<h1 class="font-bold text-lg py-4">Complete your ticket transaction</h1>
		<div>
			<template x-if="desiredTicket.type.length == 10">
    			<div>
    				
    				<?php if (isset($component)) { $__componentOriginal6c2f4d6c75dc832657bd1f428f12a794 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6c2f4d6c75dc832657bd1f428f12a794 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tickets.early-bird','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tickets.early-bird'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6c2f4d6c75dc832657bd1f428f12a794)): ?>
<?php $attributes = $__attributesOriginal6c2f4d6c75dc832657bd1f428f12a794; ?>
<?php unset($__attributesOriginal6c2f4d6c75dc832657bd1f428f12a794); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6c2f4d6c75dc832657bd1f428f12a794)): ?>
<?php $component = $__componentOriginal6c2f4d6c75dc832657bd1f428f12a794; ?>
<?php unset($__componentOriginal6c2f4d6c75dc832657bd1f428f12a794); ?>
<?php endif; ?>
    			</div>
    		</template>		
    		<template x-if="desiredTicket.type.length == 17">
    			<div>
    				<?php if (isset($component)) { $__componentOriginal43714042387c837f1eed91bf55f5218c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43714042387c837f1eed91bf55f5218c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tickets.ga','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tickets.ga'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43714042387c837f1eed91bf55f5218c)): ?>
<?php $attributes = $__attributesOriginal43714042387c837f1eed91bf55f5218c; ?>
<?php unset($__attributesOriginal43714042387c837f1eed91bf55f5218c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43714042387c837f1eed91bf55f5218c)): ?>
<?php $component = $__componentOriginal43714042387c837f1eed91bf55f5218c; ?>
<?php unset($__componentOriginal43714042387c837f1eed91bf55f5218c); ?>
<?php endif; ?>
    				
    			</div>
    		</template>
    		<template x-if="desiredTicket.type.length == 3">
    			<div>
    				<?php if (isset($component)) { $__componentOriginal5371b05dde1622a19311504c571d2ba1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5371b05dde1622a19311504c571d2ba1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tickets.vip','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tickets.vip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5371b05dde1622a19311504c571d2ba1)): ?>
<?php $attributes = $__attributesOriginal5371b05dde1622a19311504c571d2ba1; ?>
<?php unset($__attributesOriginal5371b05dde1622a19311504c571d2ba1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5371b05dde1622a19311504c571d2ba1)): ?>
<?php $component = $__componentOriginal5371b05dde1622a19311504c571d2ba1; ?>
<?php unset($__componentOriginal5371b05dde1622a19311504c571d2ba1); ?>
<?php endif; ?>
    				
    			</div>
    		</template>	
		</div>
		<div class="flex justify-center items-center mt-8 mb-14">
			<button class="bg-gray-950 text-gray-200 px-10 py-2">Proceed to checkout</button>
		</div>
	</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\cruiseHq\resources\views/dashboard/user/ticket/checkout.blade.php ENDPATH**/ ?>