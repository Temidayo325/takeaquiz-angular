<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TicketSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \App\Models\Ticket::factory()
        				->count(300)
        				->sequence(
        					['type' => 'Early bird'],
        					['type' => 'General Admission'],
                            ['type' => 'VIP'],
                            ['access_type' => 'Purchase'],
        					['access_type' => 'Gift'],
        				)
        				->create();
    }
}
