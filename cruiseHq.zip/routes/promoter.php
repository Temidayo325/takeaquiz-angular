<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Promoter\DashboardController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::prefix('promoter/dashboard')->middleware('auth')->group(function () {
    // Route::get('/profile', [DashboardController::class, 'edit'])->name('profile.edit');
    Route::get('/', [DashboardController::class, 'index']);
});

require __DIR__.'/auth.php';
